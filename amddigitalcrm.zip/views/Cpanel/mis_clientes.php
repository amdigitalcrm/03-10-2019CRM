<?php
require URLINC . 'nav_dash.php';
require URLINC . 'check_session.php';
?>

<div class="row">
	<div v-for="cliente in clientes" class="col-6 col-md-3">
		<div class="card_principal text-center">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFQSv5EkzqdxqBNS1H0YuJrtI9GWSQtVSCoit-V52u1ONLJy0V" alt="">
			<h6>{{cliente.empresa.toUpperCase()}}</h6>
			<h6>
				<small><b>Departamento : </b>{{cliente.departamento}}</small><br>
				<small><b>Provincia : </b>{{cliente.provincia}}</small><br>
				<small><b>Distrito : </b>{{cliente.distrito}}</small><br>
			</h6>
			<div>{{cliente.mensaje}}</div>
			<div>{{cliente.observacion}}</div>
		</div>
	</div>

</div>